/*  console.log("Hola desde fichero JS"); */

// variables
// reasignables
// minuscula
var resultadoOperacion = 15 * 3; //45
let resultadoOperacion2 = 13 + 6;
let edadUsuario;
console.log(edadUsuario);
console.log(resultadoOperacion);

resultadoOperacion = resultadoOperacion2 + 10; //(re)asignacion

// constantes
// no reasignables
// MAYUSCULA
const PI = 3.1416;
const MAX_ARTICULOS = 20;

// JS NO es tipado
//NUMEROS:
let edad = 23; //entero
let precioTotal = 129.45; //decimal
let diferencia = -45; //entero negativo
let facturacionGoogle = 1e10; //notación científica
let year = 2023; //sin separador de miles
let distanciaPlanetas = Infinity; //infinito

//operadores básicos: +, -, *, /
let sumaProductos = 23 + 59;
let operacion2 = 15 * 3;
let resultadoDivision = 45 / 3;
let restaProductos = 23 - 59;

//otros operadores
let potencia = 3 ** 2; //3^2 3 elevado a 2
let modulo = 10 % 4; //módulo es el resto de la división
let valor = 1;
valor = valor + 1; //valor vale 2
valor++;
valor = valor - 1;
valor--;

valor = 20;
let otroValor = valor + 1; //otroValor = 21 valor = 20
otroValor = valor++; //otroValor = 21 valor = 21

otroValor += 1; //otroValor ++;
otroValor += 10; //otroValor = otroValor + 10
otroValor *= 3; //otroValor = otroValor * 3
otroValor /= 3; //otroValor = otroValor / 3
otroValor -= 3; //otroValor = otroValor - 3

otroValor = 1;
// let pruebaMasMas = ((otroValor++)++)++; //NO LE MOLA AL NAVEGADOR
// console.log(pruebaMasMas);

//ORDEN DE LAS OPERACIONES: PARENTESIS, EXPONENTES, MULTIPLICACION, DIVISION, SUMA, RESTA
let resultadoOperacionCompleja = 3 + (15 * (34 ^ (45 + 6))) / 23;

//TEXTOS = STRINGS (CADENAS)
let texto =
  "soy un texto ñññ ÇÇççç " + resultadoOperacionCompleja + "€" + otroValor;
console.log(texto);
let texto2 =
  "soy un texto ñññ ÇÇççç" + resultadoOperacionCompleja + "soy comilla doble";
console.log(texto2);
let texto3 = `backtick me 
permite incrustar 
variables
 al texto ${resultadoOperacionCompleja} puedo seguir escribiendo ${otroValor} precio del producto 23\${}`;
console.log(texto3);
let identificacionUsuario = "Sóc l'usuari Mariona";

valor = "Marionaaaaaa";
let resultadoTotalOperaciones = valor + 20; //35
console.log(resultadoTotalOperaciones);

console.log(valor.length); //longitud de un texto almacenado en "valor"

console.log(valor.charAt(2));
console.log(valor.indexOf("o"));
let textoAleatorio = "Lorem Ipsum Dolor";
console.log(textoAleatorio.indexOf("s"));
let arrayTexto = textoAleatorio.split("o");
console.log(textoAleatorio.indexOf(arrayTexto[2]) - 1);

//JUGAR CON:
//textoAleatorio.lastIndexOf("a");

//NUMEROS:
//Librería Math
console.log(Math.floor(resultadoOperacionCompleja));
console.log(Math.ceil(resultadoOperacionCompleja));
console.log(Math.random()); //numero aleatorio de 0 a 1.
console.log(Math.ceil(Math.random() * 10)); //numero aleatorio entero del 1 al 10
console.log(Math.max(1, 5, 3, 26, -34));
console.log(Math.min(1, 5, 3, 26, -34));
console.log(Math.min(1, 5, otroValor, resultadoOperacionCompleja));
console.log(resultadoOperacionCompleja.toFixed(3)); //sin librería Math!!!!!!!
console.log(Math.PI.toFixed(4));
console.log(Math.floor(Math.PI));

//BOLEANS
// ==, ===
console.log("==", 2 == "2");
console.log("===", 2 === "2");
// >, <, >=, <=
// !=, !==

edad = 66;

// && "AND"
console.log("edad and", edad >= 16 && edad <= 65);

// || "OR"
console.log("edad or", edad >= 16 || edad <= 65);

// ! "NOT"
console.log("not", !false);

// comprobación dentro de comprobación:
// (edad >= 0 && edad <= 18) || (edad >= 75 && edad <= 100);

// VALORES TRUTHY
// true, '0', { }, [ ], 42, Date()

// VALORES FALSY
// false, 0, '', undefined, null, NaN

// IF

let number = 1;

if (number > 2) {
  console.log("Hola!");
} else {
  console.log("Adiós");
}

let idioma = "ca";

if (idioma === "es") {
  console.log("buenos días");
} else if (idioma === "ca") {
  console.log("bon dia");
} else if (idioma === "fr") {
  console.log("bonjour");
} else {
  console.log("good morning");
}

let number1 = 4;
let number2 = 8;

if (number1 === number2) {
  console.log("son iguales");
} else {
  if (number1 > number2) {
    console.log("el 1 es mayor");
  } else {
    console.log("el 2 es mayor");
  }
}

switch (idioma) {
  case "es":
    console.log("buenos días");
    break;
  case "ca":
    console.log("bon dia");
    break;
  case "fr":
    console.log("bonjour");
    break;
  default:
    console.log("good morning");
}

// LOOPS
// WHILE
let iteracion = 1;

while (iteracion < 10) {
  console.log("hola");
  iteracion++;
}

iteracion = 1;

// DO WHILE
do {
  console.log("hola desde el do while");
  iteracion++;
} while (iteracion < 10);

// FOR
let perro = "Yuna";

for (let i = 0; i < perro.length; i++) {
  console.log(perro[i]);
}

// FOR OF
let nombre = "francisca";

for (letra of nombre) {
  console.log(letra);
}

//BREAK

let num = 0;

while (num < 5) {
  console.log(num);
  num++;
  if (num == 3) {
    break;
  }
}

//CONTINUE

num = 0;

while (num < 5) {
  num++;
  if (num == 3) {
    continue;
  }
  console.log(num);
}
